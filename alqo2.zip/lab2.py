n=10                                                             
a=[0]*n
k=0
from random import randint
for i in range(n):                                                     
    a[i]=randint(-10,20)
print(a)
b=[x for x in a if x%3==2]
if len(b)!=0:
    print(sum(b)/len(b))

